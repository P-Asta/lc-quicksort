# Quick Sort
Did you make scrap magic's sort a little faster?