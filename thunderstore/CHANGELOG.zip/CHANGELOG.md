## Changelog

## 0.1.13
- **Fix**
  - chanload destory bug

## 0.1.11 / 0.1.12
- **Fix**
  - v80 :D

### 0.1.10
- **Fix**:
  - add some kr names
  - wight 0lb bug

### 0.1.9
- **Fix**:
  - add some kr names

### 0.1.8
- **Fix**:
  - `/sort`: now drops your held item first, then runs full sort.
- **Behavior**:
  - Commands now require you to be **inside the ship** (otherwise an error is shown): `/sort` (and `/ss`, `/sr`, `/sp`, `/sk`, `/sb`, `/sbl`) and `/pile`.

### 0.1.7
- **Config**:
  - Bumped `General.configVersion` to `0.1.7`.
  - Migration: if `Sorter.skippedItems` is accidentally only `shotgun, ammo`, it is reset back to the full default list.
  - Fresh install fix: when the config file does not exist yet, migrations no longer create/overwrite `Sorter.skippedItems`.

### 0.1.5
- **Client/Guest tip**: Installing **[TooManyItems](https://thunderstore.io/c/lethal-company/p/mattymatty/TooManyItems/)** may help with a vanilla issue where some items fail to sort / snap back.
- **New short commands**:
  - `/sr` → `/sort reset`
  - `/sp` → `/sort positions`
  - `/sbl` → `/sort bindings`
  - `/sk ...` → `/sort skip ...` (e.g. `/sk list`, `/sk add`, `/sk remove`)
- **Input aliases (built-in)**:
  - `double_barrel` → `shotgun`
  - `shotgun_shell` → `ammo`
- **Full sort ordering**: two-handed item types are placed first (fixed behavior; no setting).
- **Full sort placement**:
  - `sortOriginY` is applied again as an offset above detected ground.
  - Specific types are placed slightly lower: `toilet_paper`, `chemical_jug`, `cash_register`, `fancy_lamp`, `large_axle`, `v_type_engine`.
- **Config**:
  - Added `General.configVersion` (defaults to `0.1.5`).
  - Migration: if `configVersion` is missing/older and `Sorter.sortOriginY == 0.5`, it is auto-changed to `0.1`.
  - Migration: adds `shotgun`, `ammo` to `Sorter.skippedItems` if missing.

