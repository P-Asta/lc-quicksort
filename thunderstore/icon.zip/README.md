# Quick Sort

Lethal Company's item sorting mod

![alt text](https://raw.githubusercontent.com/P-Asta/lc-QuickSort/refs/heads/main/assets/image.png)

## coomand

- `/sort`: item sort
